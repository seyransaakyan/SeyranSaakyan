//
//  My_CardApp.swift
//  My Card
//
//  Created by Seyran Saakyan on 20.06.2021.
//

import SwiftUI

@main
struct My_CardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
